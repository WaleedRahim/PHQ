<?php
/*
Plugin Name: PHQ Form
Description: Plugin to Show results of PHQ and generate PDF.
Version: 1.0.1
Author: Waleed Khan
*/
?>
<?php
// Define plugin constant
define( 'MY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Load plugin files and functions
require_once MY_PLUGIN_DIR . 'includes/functions.php';

?>